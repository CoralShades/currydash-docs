# Mobile & Web Application Requirements

### Project-Type Overview

CurryDash is a **Flutter cross-platform application** targeting iOS, Android, and Web from a single codebase. This approach maximizes code reuse while enabling platform-specific optimizations where needed.

**Architecture Pattern:** Feature-first clean architecture with GetX state management
**Codebase:** Single Flutter codebase (`lib/features/`) serving all platforms
**Base:** StackFood Multivendor (commercial solution) with CurryDash customizations

### Platform Requirements

#### Mobile Platforms

| Platform | Minimum Version | Target SDK | Status |
|----------|-----------------|------------|--------|
| iOS | 12.0+ | Latest | Supported |
| Android | API 21+ (Lollipop) | API 34 | Supported |

**Cross-Platform Framework:** Flutter 3.4.4+
**State Management:** GetX with reactive controllers
**Navigation:** GetX named routes (50+ routes defined)

#### Web Platform

| Browser | Minimum Version | Status |
|---------|-----------------|--------|
| Chrome | 88+ | Primary |
| Firefox | 85+ | Supported |
| Safari | 14+ | Supported |
| Edge | 88+ | Supported |

**Web Rendering:** HTML renderer for broad compatibility
**PWA Support:** Service worker enabled for offline capability
**Responsive:** Mobile-first with desktop breakpoints

### Device Permissions & Features

| Permission | Platform | Purpose | Required |
|------------|----------|---------|----------|
| Location | iOS/Android | Delivery address, restaurant discovery | Yes |
| Camera | iOS/Android | Issue reporting photos, profile pics | Optional |
| Push Notifications | iOS/Android | Order updates, promotions | Yes |
| Storage | iOS/Android | Offline data, image cache | Yes |
| Biometrics | iOS/Android | Secure login option | Optional |

**Web Equivalents:**
- Geolocation API for address detection
- File upload for photo submission
- Web Push API for notifications (where supported)
- LocalStorage/IndexedDB for offline data

### Offline Mode Strategy

**Offline Capabilities:**
- Browse cached restaurant/menu data
- View order history
- Access saved addresses and payment methods
- Queue orders for submission when online

**Sync Strategy:**
- Background sync when connectivity restored
- Conflict resolution: Server wins for order state
- Local-first for user preferences

**Implementation:** Drift database for local persistence, API queue for offline actions

### Push Notification Strategy

| Notification Type | Trigger | Priority |
|-------------------|---------|----------|
| Order Confirmed | Order placed | High |
| Order Preparing | Vendor starts prep | Normal |
| Order Ready | Ready for pickup | High |
| Driver Assigned | Delivery assigned | Normal |
| Driver Arriving | ETA < 5 min | High |
| Order Delivered | Delivery complete | Normal |
| Promotions | Marketing campaigns | Low |
| Subscription Reminder | 24h before delivery | Normal |

**Implementation:** Firebase Cloud Messaging (FCM)
**Channels:** Separate channels for orders vs marketing (Android)
**Permissions:** Request at first order, not app launch

### App Store Compliance

#### iOS App Store
- Apple Sign-In required (implemented)
- In-app purchase compliance for subscriptions
- Privacy nutrition labels configured
- App Tracking Transparency (ATT) for advertising

#### Google Play Store
- Google Sign-In supported
- Billing library for subscriptions
- Data safety section configured
- Target API level 34 compliance

#### Common Requirements
- Privacy policy URL
- Terms of service URL
- Age rating: 4+ (no objectionable content)
- Content guidelines compliance

### Responsive Design

**Breakpoints:**

| Breakpoint | Width | Layout |
|------------|-------|--------|
| Mobile | < 600px | Single column, bottom nav |
| Tablet | 600-1024px | Two column, side nav |
| Desktop | > 1024px | Multi-column, top nav |

**Implementation:** `ResponsiveHelper` class in `lib/helper/`
**Web-specific:** Hover states via `lib/common/widgets/hover_widgets/`

### Performance Targets

| Metric | Mobile Target | Web Target |
|--------|---------------|------------|
| Cold Start | < 3s | < 2s (FCP) |
| Screen Transition | < 300ms | < 300ms |
| Image Load | < 1s | < 1s |
| API Response | < 2s | < 2s |
| App Size | < 50MB | N/A |
| Bundle Size | N/A | < 2MB (gzipped) |

### SEO Strategy (Web)

**Focus Areas:**
- Restaurant discovery pages (indexable)
- Menu/package pages (rich snippets)
- Location-based landing pages (local SEO)

**Technical SEO:**
- Server-side rendering for key pages (future)
- Meta tags per route
- Structured data for restaurants/menus
- Sitemap generation

**Current:** Client-side rendering (CSR) - SEO limited
**Future:** Consider Flutter web SEO improvements or SSR gateway

### Accessibility Level

**Target:** WCAG 2.1 AA compliance

**Implementation:**
- Semantic labels on all interactive elements
- Sufficient color contrast (4.5:1 minimum)
- Touch targets minimum 48x48dp
- Screen reader support (TalkBack/VoiceOver)
- Keyboard navigation (web)

### Implementation Considerations

**Platform-Specific Code Patterns:**
```dart
if (ResponsiveHelper.isWeb()) {
  // Web-specific behavior
}
if (GetPlatform.isAndroid || GetPlatform.isIOS) {
  // Mobile-specific behavior
}
```

**Feature Flags:**
- Use conditional compilation for platform-specific features
- Firebase Remote Config for runtime feature toggles

**Testing Strategy:**
- Widget tests for UI components
- Integration tests per platform
- Playwright for web E2E
- Emulator testing for mobile
