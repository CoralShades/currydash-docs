# Functional Requirements

### Brand Identity

- FR1: System displays CurryDash branding (name, logo, colors) across all screens
- FR2: System displays CurryDash app icon on device home screens and app stores
- FR3: System displays CurryDash splash screen during app initialization
- FR4: System removes all StackFood references from user-visible interfaces
- FR5: System applies consistent CurryDash color scheme throughout the application

**Status Update (2025-12-10):** Brand Strategy v2.0 completed
- ✅ Brand Guidelines document created ([docs/brand-strategy/brand-guidelines.md](./brand-strategy/brand-guidelines.md))
- ✅ Color System technical specification complete with WCAG 2.1 AA compliance
- ✅ Centralized color constants implemented (`lib/util/colors.dart`)
- ✅ Turmeric Gold-led Sri Lankan spice-inspired palette designed
- 🔄 Theme files and component migration in progress (see Epic 2, Story 2.2)

### Customer Account Management

- FR6: Customers can create an account using email, phone, or social login
- FR7: Customers can authenticate using saved credentials or biometrics
- FR8: Customers can manage their profile information (name, photo, preferences)
- FR9: Customers can save and manage multiple delivery addresses
- FR10: Customers can save and manage payment methods

### Restaurant & Menu Discovery

- FR11: Customers can browse available restaurants filtered by location
- FR12: Customers can search restaurants by name, cuisine type, or dish
- FR13: Customers can view restaurant details including ratings, hours, and delivery info
- FR14: Customers can browse menu items and packages for a selected restaurant
- FR15: Customers can view package details including options, pricing, and customizations

### Package Customization

- FR16: Customers can select configuration options for curry packages (protein, spice level, sides)
- FR17: System enforces minimum and maximum selection constraints per configuration
- FR18: System calculates and displays price adjustments based on selected options
- FR19: Customers can view complete customization summary before adding to cart
- FR20: Vendors can define package configurations without code changes

### Cart & Checkout

- FR21: Customers can add customized packages to cart
- FR22: Customers can modify cart contents (quantity, options, remove items)
- FR23: Customers can apply promotional codes or discounts
- FR24: Customers can select delivery address and time slot
- FR25: Customers can complete payment using saved or new payment methods
- FR26: System confirms order and provides order number

### Subscription Management

- FR27: Customers can subscribe to recurring curry pack deliveries
- FR28: Customers can select subscription frequency and delivery day
- FR29: Customers can pause or skip upcoming subscription deliveries
- FR30: Customers can modify subscription package selections
- FR31: Customers can cancel subscriptions with confirmation
- FR32: System sends subscription reminders before scheduled deliveries

### Order Tracking

- FR33: Customers can view order status in real-time
- FR34: Customers can view order history with details
- FR35: Customers can reorder from previous orders
- FR36: System sends push notifications for order status changes
- FR37: Customers can contact support regarding active orders

### Customer Support

- FR38: Customers can report issues with orders including photo upload
- FR39: Customers can view support ticket status and history
- FR40: System routes issues to appropriate support queues
- FR41: Support staff can view and respond to customer issues

### Vendor Management

- FR42: Vendors can manage restaurant profile and operating hours
- FR43: Vendors can create and edit menu items and packages
- FR44: Vendors can define package configurations and pricing
- FR45: Vendors can set item availability and seasonal offerings
- FR46: Vendors can view incoming orders grouped by time slot
- FR47: Vendors can update order status (preparing, ready)

### Admin Operations

- FR48: Admins can view platform dashboard with key metrics
- FR49: Admins can view and manage customer complaints
- FR50: Admins can view vendor performance metrics
- FR51: Admins can manage vendor status (active, paused, suspended)
- FR52: Admins can create and manage promotional campaigns

### Developer Workflow (This Initiative)

- FR53: Developers can access comprehensive setup documentation
- FR54: Developers can find assigned Jira stories with complete acceptance criteria
- FR55: Developers can run automated tests to validate code changes
- FR56: Developers can validate changes locally via emulator or browser
- FR57: System provides pre-commit quality gates for code submissions

### Project Management (This Initiative)

- FR58: Team can view all work items in Jira with proper categorization
- FR59: Stories contain required fields (points, priority, due date, acceptance criteria)
- FR60: Team can track story status through development lifecycle
- FR61: Team can access story templates for consistent story creation

### Testing Infrastructure (This Initiative)

- FR62: QA can execute Playwright tests for web application
- FR63: QA can execute tests on mobile emulators
- FR64: QA can follow documented manual testing checklists
- FR65: System runs automated tests as part of build process
- FR66: Test results are visible and actionable for development team

### Notifications

- FR67: System sends push notifications for order updates (confirmed, preparing, delivered)
- FR68: System sends notifications for subscription reminders
- FR69: System sends notifications for promotional offers
- FR70: Customers can manage notification preferences
