# Product Scope

## MVP - Minimum Viable Product

**Vendor Portal (CAR) - Must Have:**
- Self-service vendor registration and onboarding
- Restaurant profile management (hours, location, delivery zones)
- Menu and package management (CRUD for items, curry pack configurations)
- Order dashboard with real-time incoming orders
- Order status workflow (accept, preparing, ready)
- Basic analytics (orders, revenue, ratings)
- Notification system for new orders

**Admin Dashboard (CAD) - Must Have:**
- Vendor application review and approval workflow
- Vendor management (view, edit, suspend, activate)
- Order monitoring and search
- Customer complaint queue
- Basic platform analytics
- User/role management

**Backend APIs (CUR) - Must Have:**
- All endpoints required by frontend PRD (70 FRs)
- Subscription management APIs
- Package configuration APIs
- Payment processing integration (Stripe)
- Push notification triggers

## Growth Features (Post-MVP)

**Vendor Portal Enhancements:**
- Advanced analytics with trend analysis and benchmarking
- Subscription forecasting and demand planning
- Bulk menu operations (import/export, batch updates)
- Multi-location support for vendor chains
- Promotional campaign creation tools
- Customer communication features (respond to reviews)

**Admin Dashboard Enhancements:**
- Advanced reporting with custom report builder
- Geographic analytics and heat maps
- Vendor performance scoring and automated alerts
- Quality audit workflows and checklists
- Bulk operations for common admin tasks
- Financial reconciliation and payout management

**Platform Capabilities:**
- Multi-language content management (Sinhalese, Tamil, English)
- A/B testing infrastructure
- Advanced search with filters and facets
- Integration with external analytics (Google Analytics, Mixpanel)

## Vision (Future)

**Cultural Platform Excellence:**
- AI-powered authenticity verification for vendor cuisine claims
- Community-driven vendor ratings incorporating cultural authenticity
- Heritage storytelling features for vendor profiles
- Cultural event integration (festival menus, seasonal specials)

**Operational Excellence:**
- Fully automated vendor onboarding with document verification
- Predictive demand forecasting for subscription optimization
- Real-time driver tracking integration
- Automated quality control with image recognition

**Scale & Expansion:**
- Multi-region support (other Australian cities)
- White-label vendor portal for enterprise vendors
- API marketplace for third-party integrations
- Self-service analytics with natural language queries
