# Cross-Project Integration

## Backend ↔ Mobile/Web

**API Communication**:
- Mobile/Web apps (Flutter) call backend APIs
- Authentication via JWT tokens
- JSON request/response format
- See [API Specification](api-specification.md) for endpoints

**Shared Concerns**:
- **Brand Identity**: Backend error messages use [Brand Guidelines](brand-strategy/brand-guidelines.md) tone
- **API Contract**: Backend implements server-side validation for [API Reference (Client)](https://github.com/CoralShades/User-Web-Mobile/blob/main/docs/api-reference.md) endpoints
- **Testing**: E2E tests coordinate backend + mobile/web ([Testing Strategy](https://github.com/CoralShades/User-Web-Mobile/blob/main/docs/testing.md))

## Admin Dashboard ↔ Vendor Dashboard

**Workflow Integration**:
- Admin (CAD) approves vendors registered via Vendor Dashboard (CAR)
- Admin moderates packages created by vendors
- Admin resolves disputes between customers and vendors

**See**: [Integration Architecture](integration-architecture.md) for detailed workflows

---
