# Overview

The CurryDash backend is built on **Laravel 9.x** with a **modular architecture** pattern. It serves as the central hub coordinating:

- **Admin Dashboard** (CAD Jira project)
- **Vendor Dashboard** (CAR Jira project)
- **Customer Mobile/Web Apps** (PACK & CCW Jira projects)
- **Central Orchestration** (CUR Jira project)
- **Package System** (CPFP Jira project)

## Key Architecture Principles

1. **Modular Design**: Laravel Modules (nWidart) for feature encapsulation
2. **Service-Oriented**: Business logic in service layers, not controllers
3. **Eloquent ORM**: Database abstraction with model relationships
4. **RESTful APIs**: JSON API endpoints for mobile/web clients
5. **JWT Authentication**: Token-based stateless authentication
6. **Central Orchestration**: CentralLogics layer coordinates cross-project concerns

## Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Framework** | Laravel 9.x | PHP web application framework |
| **Language** | PHP 8.1+ | Server-side scripting |
| **Database** | MySQL 8.0 | Relational data storage |
| **Cache** | Redis | Session, cache, queue storage |
| **Queue** | Laravel Queues | Background job processing |
| **Storage** | Local / S3 | File storage (images, documents) |
| **Modules** | nWidart/laravel-modules | Modular architecture |

## Related Documentation

📚 **Cross-Project References**:
- **Mobile/Web Architecture**: [User-Web-Mobile/docs/architecture.md](https://github.com/CoralShades/User-Web-Mobile/blob/main/docs/architecture.md) - Flutter feature-first clean architecture
- **API Reference (Client)**: [User-Web-Mobile/docs/api-reference.md](https://github.com/CoralShades/User-Web-Mobile/blob/main/docs/api-reference.md) - 100+ endpoints from mobile perspective
- **API Specification (Server)**: [api-specification.md](api-specification.md) - Backend endpoint implementation details
- **Database Schema**: [database-schema.md](database-schema.md) - ERD and table specifications

---
