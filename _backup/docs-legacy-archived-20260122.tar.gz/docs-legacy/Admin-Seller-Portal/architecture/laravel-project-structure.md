# Laravel Project Structure

## Top-Level Directory Structure

```
Admin-Seller_Portal/
├── app/                          # Application core
│   ├── CentralLogics/            # ✨ CUR orchestration layer (custom)
│   ├── Console/                  # Artisan commands
│   ├── Exceptions/               # Exception handlers
│   ├── Http/                     # Controllers, middleware, requests
│   │   ├── Controllers/
│   │   │   ├── Admin/            # CAD project controllers
│   │   │   ├── Api/V1/           # API controllers (mobile/web)
│   │   │   └── Vendor/           # CAR project controllers
│   │   ├── Middleware/           # Request middleware
│   │   └── Requests/             # Form request validation
│   ├── Library/                  # Third-party integrations
│   ├── Mail/                     # Email templates (Mailable classes)
│   ├── Models/                   # Eloquent models
│   ├── Observers/                # Model observers (events)
│   ├── Providers/                # Service providers
│   ├── Rules/                    # Custom validation rules
│   ├── Scopes/                   # Query scopes
│   ├── Traits/                   # Reusable traits
│   └── helpers.php               # Global helper functions
├── bootstrap/                    # Framework bootstrap
├── config/                       # Configuration files
│   ├── auth.php                  # Authentication guards
│   ├── database.php              # Database connections
│   ├── mail.php                  # Email configuration
│   └── ...
├── database/                     # Database files
│   ├── factories/                # Model factories (testing/seeding)
│   ├── migrations/               # Database migrations
│   └── seeders/                  # Database seeders
├── docs/                         # ✨ Project documentation (BMAD)
│   ├── sprint-artifacts/         # Sprint tracking
│   ├── index.md                  # Documentation hub
│   ├── architecture.md           # This file
│   └── ...
├── Modules/                      # ✨ Modular architecture (nWidart)
│   ├── TaxModule/                # Tax calculation module
│   └── ...                       # Other feature modules
├── public/                       # Publicly accessible files
│   ├── index.php                 # Entry point
│   └── storage/                  # Symlink to storage/app/public
├── resources/                    # Views, assets
│   ├── views/                    # Blade templates
│   │   ├── admin-views/          # CAD dashboard views
│   │   ├── vendor-views/         # CAR dashboard views
│   │   └── layouts/              # Shared layouts
│   └── lang/                     # Localization files
├── routes/                       # Route definitions
│   ├── api/                      # API routes
│   │   ├── v1/                   # API version 1
│   │   │   └── api.php           # Main API routes
│   │   └── v2/                   # API version 2 (future)
│   ├── admin.php                 # Admin dashboard routes (CAD)
│   ├── vendor.php                # Vendor dashboard routes (CAR)
│   ├── web.php                   # Web routes (landing pages)
│   └── channels.php              # Broadcast channels
├── storage/                      # Application storage
│   ├── app/                      # Application files
│   ├── framework/                # Framework files
│   └── logs/                     # Application logs
├── tests/                        # PHPUnit tests
│   ├── Feature/                  # Feature tests
│   └── Unit/                     # Unit tests
├── vendor/                       # Composer dependencies
├── .env                          # Environment configuration
├── artisan                       # Artisan CLI
├── composer.json                 # PHP dependencies
└── package.json                  # Node dependencies
```

## Key Directories Explained

### `app/CentralLogics/` (CUR Orchestration)

Custom directory for **cross-project orchestration** logic:

**Purpose**: Central utilities shared across CAD, CAR, PACK, CCW, CPFP projects

**Key Files**:
- `Helpers.php` - Static utility methods (error formatting, payment helpers, notification triggers, settings retrieval, image URL generation)
- `OrderLogic.php` - Order lifecycle orchestration
- `RestaurantLogic.php` - Restaurant/vendor business logic

**Usage Pattern**:
```php
use App\CentralLogics\Helpers;

// Error formatting
$errors = Helpers::error_processor($validator);

// Get business setting
$scheduleOrderEnabled = Helpers::schedule_order();

// Generate full image URL
$imageUrl = Helpers::get_full_url('package', $imageName, 'public');
```

**Jira Mapping**: CUR project (Central management)

### `app/Http/Controllers/`

Controllers organized by **user role** and **API version**:

**Admin Controllers** (`Admin/`):
- `DashboardController.php` - Admin analytics dashboard
- `VendorController.php` - Vendor management (approval, suspension)
- `PackageController.php` - Package approval/moderation
- `OrderController.php` - Order monitoring and dispute resolution
- `ReportController.php` - Platform reporting
- **Jira**: CAD project

**Vendor Controllers** (`Vendor/`):
- `ProfileController.php` - Vendor profile management
- `PackageController.php` - Package CRUD operations
- `OrderController.php` - Order fulfillment
- `ReportController.php` - Vendor analytics
- **Jira**: CAR project

**API Controllers** (`Api/V1/`):
- `AuthController.php` - Customer authentication
- `PackageController.php` - Package listing and customization
- `RestaurantController.php` - Restaurant discovery
- `OrderController.php` - Order placement and tracking
- `SubscriptionController.php` - Subscription management
- **Jira**: CUR project (serves PACK and CCW frontends)

**Pattern**:
```php
class PackageController extends Controller
{
    public function index(Request $request)
    {
        // 1. Validate request
        $validator = Validator::make($request->all(), [
            'restaurant_id' => 'required|exists:restaurants,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        // 2. Retrieve data via Eloquent
        $packages = Package::where('restaurant_id', $request->restaurant_id)
            ->where('status', true)
            ->with(['configurations.options.food'])
            ->get();

        // 3. Return JSON response
        return response()->json($packages, 200);
    }
}
```

### `app/Models/`

Eloquent models representing database tables:

**User Management**:
- `User.php` - Customer accounts
- `Admin.php` - Admin accounts
- `Vendor.php` - Vendor accounts (restaurant owners)

**Restaurant & Menu**:
- `Restaurant.php` - Restaurant profiles
- `Category.php` - Food categories
- `Food.php` - Individual menu items
- `AddOn.php` - Add-on items

**Package System** (CPFP):
- `Package.php` - Meal packages/combos
- `PackageConfiguration.php` - Configuration groups
- `PackageOption.php` - Selectable options

**Orders & Commerce**:
- `Order.php` - Order records
- `OrderDetail.php` - Order line items
- `Cart.php` - Shopping cart
- `Subscription.php` - Recurring deliveries

**See**: [Database Schema](database-schema.md) for full ERD

### `Modules/` (Modular Architecture)

Laravel Modules (nWidart) for feature encapsulation:

**Current Modules**:
- `TaxModule/` - Tax calculation logic
- *(Additional modules can be added)*

**Module Structure** (Standard):
```
Modules/TaxModule/
├── Config/
├── Console/
├── Database/
│   ├── Migrations/
│   └── Seeders/
├── Entities/            # Models
├── Http/
│   ├── Controllers/
│   └── Requests/
├── Providers/
│   ├── TaxModuleServiceProvider.php
│   └── RouteServiceProvider.php
├── Resources/
│   ├── assets/
│   └── views/
├── Routes/
│   ├── api.php
│   └── web.php
├── Tests/
├── composer.json
└── module.json
```

**Benefits**:
- Independent feature development
- Clear module boundaries
- Reusable across projects
- Can be enabled/disabled via `modules_statuses.json`

---
